﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics; // Подключение BigInteger
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Windows.Media;

namespace EnemyEditor
{
    public class CPlayer
    {
        public int Level { get; set; }
        public BigInteger Gold { get; set; }
        public BigInteger Damage { get; set; }
        public BigInteger UpgradeCost { get; set; }
        public double DamageModifier { get; set; }
        public double UpgradeModifier { get; set; }

        public void UpgradeDamage()
        {
            if (Gold >= UpgradeCost)
            {
                Gold -= UpgradeCost;
                Damage = BigInteger.Multiply(Damage, (BigInteger)DamageModifier);
                UpgradeCost = BigInteger.Multiply(UpgradeCost, (BigInteger)(UpgradeModifier * Level));
                Level++;
            }
        }
    }

    public class CEnemy
    {
        public string Name { get; set; }
        public BigInteger HitPoints { get; set; }
        public BigInteger Gold { get; set; }
        public Image Icon { get; set; }
    }

    public class CEnemyTemplate
    {
        public string Name { get; set; }
        public BigInteger BaseLife { get; set; }
        public BigInteger BaseGold { get; set; }
        public double LifeModifier { get; set; }
        public double GoldModifier { get; set; }
        public double SpawnChance { get; set; }
        public Image Icon { get; set; }

        public CEnemy CreateEnemy(int playerLevel)
        {
            return new CEnemy
            {
                Name = Name,
                HitPoints = BigInteger.Multiply(BaseLife, (BigInteger)(LifeModifier * playerLevel)),
                Gold = BigInteger.Multiply(BaseGold, (BigInteger)(GoldModifier * playerLevel)),
                Icon = Icon
            };
        }
    }

    public partial class MainWindow : Window
    {
        private CPlayer player;
        private List<CEnemyTemplate> enemyTemplates;
        private CEnemy currentEnemy;

        public MainWindow()
        {
            try
            {
                InitializeComponent();
                InitializeGame();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error during initialization: " + ex.Message);
            }
        }

        private void InitializeGame()
        {
            player = new CPlayer
            {
                Level = 1,
                Gold = 100,
                Damage = 10,
                UpgradeCost = 50,
                DamageModifier = 1.5,
                UpgradeModifier = 1.2
            };

            enemyTemplates = LoadEnemyTemplates();
            NormalizeChances();
            SelectNextEnemy();
            UpdateUI();
        }

        private List<CEnemyTemplate> LoadEnemyTemplates()
        {
            return new List<CEnemyTemplate>
            {
                new CEnemyTemplate
                {
                    Name = "Armored Knight",
                    BaseLife = 100,
                    BaseGold = 10,
                    LifeModifier = 1.2,
                    GoldModifier = 1.1,
                    SpawnChance = 50,
                    Icon = new Image()
    {
        Source = new BitmapImage(new Uri("Images/Armored_Knight.jpg", UriKind.Relative))
    }
},
                new CEnemyTemplate
                {
                    Name = "Axe Knight",
                    BaseLife = 200,
                    BaseGold = 20,
                    LifeModifier = 1.3,
                    GoldModifier = 1.2,
                    SpawnChance = 30,
                    Icon = new Image()
    {
        Source = new BitmapImage(new Uri("Images/Axe_Knight.png", UriKind.Relative))
    }
},
                new CEnemyTemplate
                {
                    Name = "Red Knight",
                    BaseLife = 400,
                    BaseGold = 50,
                    LifeModifier = 1.4,
                    GoldModifier = 1.3,
                    SpawnChance = 25,
                     Icon = new Image()
    {
        Source = new BitmapImage(new Uri("Images/Red_Knight.png", UriKind.Relative))
    }
},
                new CEnemyTemplate
                {
                    Name = "Blue Knight",
                    BaseLife = 500,
                    BaseGold = 100,
                    LifeModifier = 1.5,
                    GoldModifier = 1.4,
                    SpawnChance = 20,
                     Icon = new Image()
    {
        Source = new BitmapImage(new Uri("Images/Blue_Knight.png", UriKind.Relative))
    }
}
            };
        }

        private void NormalizeChances()
        {
            double sum = enemyTemplates.Sum(e => e.SpawnChance);
            foreach (var template in enemyTemplates)
            {
                template.SpawnChance /= sum;
            }
        }

        private void SelectNextEnemy()
        {
            Random random = new Random();
            double chance = random.NextDouble();
            double cumulative = 0;

            foreach (var template in enemyTemplates)
            {
                cumulative += template.SpawnChance;
                if (chance <= cumulative)
                {
                    currentEnemy = template.CreateEnemy(player.Level);
                    break;
                }
            }
        }

        private void EnemyIcon_Click(object sender, RoutedEventArgs e)
        {
            if (currentEnemy == null) return;

            currentEnemy.HitPoints -= player.Damage;
            if (currentEnemy.HitPoints <= 0)
            {
                player.Gold += currentEnemy.Gold;
                SelectNextEnemy();
            }
            UpdateUI();
        }

        private void UpgradeDamageButton_Click(object sender, RoutedEventArgs e)
        {
            player.UpgradeDamage();
            UpdateUI();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Save functionality is not implemented yet.");
        }

        private void LoadButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Load functionality is not implemented yet.");
        }

        private void UpdateUI()
        {
            PlayerGoldTextBlock.Text = player.Gold.ToString();
            PlayerDamageTextBlock.Text = player.Damage.ToString();
            UpgradeCostTextBlock.Text = player.UpgradeCost.ToString();

            if (currentEnemy != null)
            {
                EnemyNameTextBlock.Text = currentEnemy.Name;
                EnemyHitPointsTextBlock.Text = currentEnemy.HitPoints.ToString();
                EnemyGoldTextBlock.Text = currentEnemy.Gold.ToString();
                EnemyIconImage.Source = currentEnemy.Icon?.Source;
            }
        }
    }
}